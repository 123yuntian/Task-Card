/**
 * js/store.js — 状态管理（应用的单一数据源）
 * 职责：
 *  1. 在内存中持有全部任务数据，是唯一可写的数据源；
 *  2. 提供任务的增删改查（CRUD）与状态机迁移方法；
 *  3. 内置极简发布/订阅：每次数据变化后先持久化，再广播 'change' 事件；
 *  4. 倒计时结束时额外广播 'task:expired' 事件（供视图层弹模态框）。
 *
 * 状态机：
 *   available（待接取）→ accepted（进行中）→ done（已完成）
 *        accepted --倒计时结束--> failed（失败）
 *        accepted/failed --手动搁置--> shelved（已搁置，归入失败栏）
 *        failed/shelved --重新接取--> available
 *
 * 倒计时设计：只存绝对截止时间戳 deadline，剩余时间由视图层实时计算：
 *   remaining = deadline - Date.now()
 */

import { loadData, saveData, loadLegacyStates, clearLegacy, SCHEMA_VERSION } from './storage.js';

/* ================= 事件总线（极简发布/订阅） ================= */

/** @type {Map<string, Set<Function>>} event -> 监听器集合 */
const listeners = new Map();

/**
 * 订阅事件。
 * @param {string} event 事件名（'change' | 'task:expired'）
 * @param {Function} handler 回调
 * @returns {Function} 取消订阅的函数
 */
export function on(event, handler) {
    if (!listeners.has(event)) listeners.set(event, new Set());
    listeners.get(event).add(handler);
    return () => listeners.get(event).delete(handler);
}

/** 广播事件（内部使用） */
function emit(event, payload) {
    const set = listeners.get(event);
    if (set) set.forEach(fn => fn(payload));
}

/* ================= 内置示例任务 ================= */

/**
 * 首次启动（或数据损坏）时使用的默认任务。
 * pomodoros（番茄钟数）不在此存储，由视图层按 Math.ceil(suggestedTime / 25) 派生。
 */
const DEFAULT_TASKS = [
    {
        id: 't1',
        goal: '学习 JavaScript 基础',
        suggestion: '每天学习 30 分钟，结合实际项目练习',
        measures: '阅读 MDN 文档，完成 5 个练习题，写一个小应用',
        knowledge: '变量、函数、数组、对象、DOM 操作',
        suggestedTime: 30,
        priority: 'high',
        blockedBy: []
    },
    {
        id: 't2',
        goal: '完成 CSS 布局练习',
        suggestion: '从简单到复杂，逐步掌握各种布局方式',
        measures: '练习 Flexbox 和 Grid 布局，实现 3 个响应式页面',
        knowledge: 'Flexbox、Grid、响应式设计、媒体查询',
        suggestedTime: 45,
        priority: 'medium',
        blockedBy: []
    },
    {
        id: 't3',
        goal: '阅读技术文档',
        suggestion: '选择一个感兴趣的技术栈，深入阅读官方文档',
        measures: '每天阅读 20 页，做笔记，总结核心概念',
        knowledge: '文档阅读方法、技术选型、架构设计',
        suggestedTime: 60,
        priority: 'low',
        blockedBy: ['t1'] // 演示任务依赖：需先完成 t1
    }
];

/* ================= 内部状态 ================= */

/** 内存中的全部状态（唯一数据源） */
let state = {
    tasks: [],
    lastResetDate: null // 上次执行"每日重置"的日期（本地日期串）
};

/** 生成本地日期串，用于跨天判断（如 "2026-10-6"） */
function todayStr(d = new Date()) {
    return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

/** 字段补全：保证任何来源的任务对象都具备完整字段（容错） */
function normalizeTask(t) {
    return {
        id: t.id,
        goal: t.goal || '未命名任务',
        suggestion: t.suggestion || '',
        measures: t.measures || '',
        knowledge: t.knowledge || '',
        suggestedTime: Number(t.suggestedTime) > 0 ? Number(t.suggestedTime) : 25,
        priority: ['high', 'medium', 'low'].includes(t.priority) ? t.priority : 'medium',
        blockedBy: Array.isArray(t.blockedBy) ? t.blockedBy : [],
        status: t.status || 'available',
        deadline: typeof t.deadline === 'number' ? t.deadline : null, // 绝对时间戳
        shelveReason: t.shelveReason || '',
        createdAt: t.createdAt || Date.now(),
        acceptedAt: t.acceptedAt || null,
        completedAt: t.completedAt || null,
        archived: t.archived === true,
        failedAt: t.failedAt || null,
        // 派活接入字段（场3阶段6）：非派活任务为 null。不能是 undefined，JSON.stringify 会把 undefined 键丢掉
        dispatchKey: t.dispatchKey || null, // 跨日稳定逻辑键
        sourceKey: t.sourceKey || null,
        dispatchContentRevision: t.dispatchContentRevision || null,
        sourceTitle: t.sourceTitle || null
    };
}

/** 持久化当前状态；返回 saveData 的布尔结果（T-3 只读锁 / 配额超限时为 false） */
function persist(opts) {
    return saveData({ tasks: state.tasks, lastResetDate: state.lastResetDate }, opts);
}

/** 持久化并广播变化（所有写操作的统一出口）；saved 随事件传出，供调用方提示「本地保存失败」 */
function persistAndEmit(detail) {
    const saved = persist();
    emit('change', { ...detail, saved });
    return saved;
}

/* ================= 初始化与旧数据迁移 ================= */

/** 初始化：加载持久化数据；无数据则用默认任务兜底；随后执行每日重置检查 */
export function init() {
    const data = loadData();

    if (data && Array.isArray(data.tasks)) {
        // 正常分支：使用磁盘数据（逐条补全字段，容忍脏数据）
        state.tasks = data.tasks.map(normalizeTask);
        state.lastResetDate = data.lastResetDate || todayStr();
    } else {
        // 兜底分支：播种默认任务，并尝试迁移重构前的旧版状态
        state.tasks = DEFAULT_TASKS.map(normalizeTask);
        state.lastResetDate = todayStr();
        applyLegacyStates();
        // noCloud：首次播种只落本机。否则新设备（手机）第一次打开，
        // 会拿这 3 条默认任务把云端已有的真实数据覆盖掉。
        persist({ noCloud: true });
    }

    dailyResetIfNeeded();
}

/**
 * 采用云端数据覆盖当前状态（由 app.js 在启动后异步调用）。
 *
 * 不走 persist()：云端刚拉下来的数据不必立刻推回去，省一次往返。
 * 但仍会 emit('change')，让界面重绘成云端内容。
 *
 * @param {{tasks:Array, lastResetDate:string}} data
 * @returns {boolean} 是否采用
 */
export function applyRemote(data) {
    if (!data || !Array.isArray(data.tasks)) return false;
    state.tasks = data.tasks.map(normalizeTask);
    state.lastResetDate = data.lastResetDate || todayStr();
    dailyResetIfNeeded();
    emit('change', { type: 'remote-sync', saved: true });
    return true;
}

/**
 * 取当前状态的浅拷贝（供 app.js 做"首次上传到云端"用）。
 * @returns {{tasks:Array, lastResetDate:string}}
 */
export function getSnapshot() {
    return { tasks: state.tasks, lastResetDate: state.lastResetDate };
}

/**
 * 合并云端新增的任务 —— 只追加本地没有的 id，绝不覆盖本地已有任务的状态。
 *
 * 用途：页面开着时的定时轮询。让"在 WorkBuddy 对话里派的新活"不刷新也能出现在看板上。
 * 为什么不做全量覆盖：本地可能正在进行倒计时（accepted），云端那份可能是几分钟前的，
 * 全量覆盖会把倒计时重置或让状态倒退。
 *
 * @param {Array} remoteTasks 云端任务数组
 * @returns {number} 实际追加的条数
 */
export function mergeRemoteTasks(remoteTasks) {
    if (!Array.isArray(remoteTasks) || !remoteTasks.length) return 0;
    const ids = new Set(state.tasks.map(t => t.id));
    const incoming = remoteTasks
        .filter(t => t && t.id && !ids.has(t.id))
        .map(normalizeTask);
    if (!incoming.length) return 0;
    state.tasks.push(...incoming);
    persistAndEmit({ type: 'remote-merge', added: incoming.length });
    return incoming.length;
}

/**
 * 一次性迁移重构前旧版数据（localStorage 键 taskStates）。
 * 旧 id 1/2/3 按顺序映射到新 id t1/t2/t3：
 *   completed   -> done
 *   in-progress -> accepted（旧数据无 deadline，重新给予完整时长）
 *   pending     -> available（默认状态，无需处理）
 */
function applyLegacyStates() {
    const legacy = loadLegacyStates();
    if (!legacy) return;

    const idMap = { '1': 't1', '2': 't2', '3': 't3' };
    for (const [oldId, st] of Object.entries(legacy)) {
        const task = getTask(idMap[oldId]);
        if (!task || !st) continue;
        if (st.status === 'completed') {
            task.status = 'done';
            task.completedAt = Date.now();
        } else if (st.status === 'in-progress') {
            task.status = 'accepted';
            task.acceptedAt = Date.now();
            task.deadline = Date.now() + task.suggestedTime * 60 * 1000;
        }
    }
    clearLegacy(); // 迁移完成后清除旧数据，避免重复迁移
}

/* ================= 查询接口 ================= */

/** 获取全部任务（返回内部数组的引用，调用方请勿直接修改） */
export function getTasks() {
    return state.tasks;
}

/** 按 id 获取单个任务 */
export function getTask(id) {
    return state.tasks.find(t => t.id === id) || null;
}

/**
 * 获取某任务当前仍未完成的阻塞任务列表。
 * @param {object} task
 * @returns {Array} 未完成的阻塞任务对象数组（空数组表示未被阻塞）
 */
export function getBlockers(task) {
    return task.blockedBy
        .map(bid => getTask(bid))
        .filter(t => t && t.status !== 'done');
}

/* ================= CRUD ================= */

/**
 * 新增任务。
 * @param {object} fields 任务字段（id 可省略，自动生成）
 * @returns {object} 新建的任务
 */
export function addTask(fields) {
    const task = normalizeTask({
        ...fields,
        id: fields.id || `t${Date.now()}`,
        status: 'available'
    });
    state.tasks.push(task);
    persistAndEmit({ type: 'add', id: task.id });
    return task;
}

/**
 * 更新任务基础字段（不改状态机；状态迁移请用专用方法）。
 * @param {string} id
 * @param {object} patch 要合并的字段
 */
export function updateTask(id, patch) {
    const task = getTask(id);
    if (!task) return false;
    Object.assign(task, normalizeTask({ ...task, ...patch }));
    persistAndEmit({ type: 'update', id });
    return true;
}

export function archiveTask(id) {
    const task = getTask(id);
    if (!task) return false;
    task.archived = true;
    persistAndEmit({ type: 'archive', id });
    return true;
}

export function unarchiveTask(id) {
    const task = getTask(id);
    if (!task) return false;
    task.archived = false;
    persistAndEmit({ type: 'unarchive', id });
    return true;
}

/** 删除任务；同时把该 id 从其他任务的 blockedBy 中移除，避免悬空依赖 */
export function deleteTask(id) {
    const idx = state.tasks.findIndex(t => t.id === id);
    if (idx === -1) return false;
    state.tasks.splice(idx, 1);
    state.tasks.forEach(t => {
        t.blockedBy = t.blockedBy.filter(bid => bid !== id);
    });
    persistAndEmit({ type: 'delete', id });
    return true;
}

/* ================= 状态机迁移 ================= */

/* ================= 统一命令入口（阶段6后半 · c） ================= */

/**
 * 五种状态操作（accept/complete/fail/delay/shelve）的唯一写入口：
 * render 的五个旧导出与 workbench 的服务端成功回写都走这里，避免同一状态出现第二条写入路径。
 *  - 只做本地写入，绝不发网络请求（双向同步是阶段7 的事）；
 *  - 目标任务先按 id 找（render 传 id），找不到再按 dispatchKey 找（workbench 传 dispatchKey）；
 *  - accept/delay 的 payload.deadline（服务端算好的绝对时间戳）优先，没有才本地计算，
 *    避免两套时钟导致刷新后倒计时跳变。
 * @param {{type:'accept'|'complete'|'fail'|'delay'|'shelve', id?:string, dispatchKey?:string, payload?:object}} cmd
 * @returns {{ok:boolean, saved:boolean, taskId:string|null, reason?:string, blockers?:Array}}
 */
export function applyTaskCommand(cmd) {
    const type = cmd?.type;
    const payload = (cmd?.payload && typeof cmd.payload === 'object') ? cmd.payload : {};
    const task = (cmd?.id ? getTask(cmd.id) : null)
        || (cmd?.dispatchKey ? state.tasks.find(t => t.dispatchKey === cmd.dispatchKey) : null);
    if (!task) return { ok: false, saved: false, taskId: null, reason: 'unknown_task' };

    // 服务端成功后的快照已包含本次操作结果；新卡也已用它播种，不能再迁移或重复延时。
    if (payload.execution && ['accept', 'complete', 'fail', 'delay', 'shelve'].includes(type)) {
        const exec = payload.execution;
        task.status = exec.execution;
        task.deadline = exec.deadline ?? null;
        for (const field of ['acceptedAt', 'completedAt', 'failedAt']) {
            if (Object.prototype.hasOwnProperty.call(exec, field)) task[field] = exec[field];
        }
        task.shelveReason = exec.shelveReason ?? '';
        const saved = persistAndEmit({ type, id: task.id });
        return { ok: true, saved, taskId: task.id };
    }

    const now = Date.now();
    switch (type) {
        case 'accept': {
            if (task.status !== 'available') return { ok: false, saved: false, taskId: task.id, reason: 'invalid-state' };
            const blockers = getBlockers(task);
            if (blockers.length > 0) return { ok: false, saved: false, taskId: task.id, reason: 'blocked', blockers };
            task.status = 'accepted';
            task.acceptedAt = now;
            // 关键：只存绝对截止时间戳，不存剩余秒数；服务端 deadline 优先（②：绝不两套时钟）
            task.deadline = typeof payload.deadline === 'number' ? payload.deadline : now + task.suggestedTime * 60 * 1000;
            const saved = persistAndEmit({ type: 'accept', id: task.id });
            return { ok: true, saved, taskId: task.id };
        }
        case 'complete': {
            if (task.status !== 'accepted') return { ok: false, saved: false, taskId: task.id, reason: 'invalid-state' };
            task.status = 'done';
            task.completedAt = now;
            task.deadline = null;
            const saved = persistAndEmit({ type: 'complete', id: task.id });
            return { ok: true, saved, taskId: task.id };
        }
        case 'fail': {
            if (task.status !== 'accepted') return { ok: false, saved: false, taskId: task.id, reason: 'invalid-state' };
            task.status = 'failed';
            task.failedAt = now;
            task.deadline = null;
            const saved = persist();
            emit('change', { type: 'fail', id: task.id, saved });
            // 只有 timer 过期路径才广播（视图层据此弹"延时/搁置"模态框）；
            // workbench 手动标记失败走同入口但不带 expired，避免看板误弹模态框
            if (payload.expired) emit('task:expired', { id: task.id });
            return { ok: true, saved, taskId: task.id };
        }
        case 'delay': {
            const ms = payload.extendMinutes * 60 * 1000;
            if (!Number.isFinite(ms) || ms <= 0) return { ok: false, saved: false, taskId: task.id, reason: 'invalid-payload' };
            if (task.status === 'accepted' && task.deadline) {
                // 服务端算好的绝对 deadline 优先，没有才自己加
                task.deadline = typeof payload.deadline === 'number' ? payload.deadline : task.deadline + ms;
            } else if (task.status === 'failed' || task.status === 'shelved') {
                task.status = 'accepted';
                task.deadline = typeof payload.deadline === 'number' ? payload.deadline : now + ms;
                task.failedAt = null;
                task.shelveReason = '';
            } else {
                return { ok: false, saved: false, taskId: task.id, reason: 'invalid-state' };
            }
            const saved = persistAndEmit({ type: 'delay', id: task.id, ms });
            return { ok: true, saved, taskId: task.id };
        }
        case 'shelve': {
            if (!['accepted', 'failed', 'shelved'].includes(task.status)) {
                return { ok: false, saved: false, taskId: task.id, reason: 'invalid-state' };
            }
            task.status = 'shelved';
            task.shelveReason = typeof payload.reason === 'string' ? payload.reason : '';
            task.deadline = null;
            if (!task.failedAt) task.failedAt = now;
            const saved = persistAndEmit({ type: 'shelve', id: task.id });
            return { ok: true, saved, taskId: task.id };
        }
        case 'reaccept': {
            // render 的 reacceptTask 也从这条漏斗走（用户拍板：不许五个进漏斗一个走侧门）
            if (!['failed', 'shelved', 'done'].includes(task.status)) {
                return { ok: false, saved: false, taskId: task.id, reason: 'invalid-state' };
            }
            task.status = 'available';
            task.deadline = null;
            task.completedAt = null;
            task.failedAt = null;
            task.shelveReason = '';
            const saved = persistAndEmit({ type: 'reaccept', id: task.id });
            return { ok: true, saved, taskId: task.id };
        }
        default:
            return { ok: false, saved: false, taskId: task.id, reason: 'unknown_type' };
    }
}

/**
 * 接取任务：available -> accepted。
 * 依赖检查：若 blockedBy 中存在未完成任务，则拒绝并返回阻塞列表。
 * @returns {{ ok:boolean, reason?:string, blockers?:Array }}
 */
export function acceptTask(id) {
    const result = applyTaskCommand({ type: 'accept', id });
    if (result.ok) return { ok: true };
    const out = { ok: false, reason: result.reason };
    if (result.reason === 'blocked') out.blockers = result.blockers;
    return out;
}

/** 完成任务：accepted -> done */
export function completeTask(id) {
    return applyTaskCommand({ type: 'complete', id }).ok;
}

/**
 * 延时任务。
 *  - accepted：deadline 直接增加 ms；
 *  - failed / shelved：复活为 accepted，deadline 从当前时刻重新计算 ms。
 * @param {string} id
 * @param {number} ms 延时时长（毫秒）
 */
export function delayTask(id, ms) {
    return applyTaskCommand({ type: 'delay', id, payload: { extendMinutes: ms / 60000 } }).ok;
}

/**
 * 搁置任务：accepted/failed -> shelved，并记录可选的搁置原因。
 * 搁置任务归入失败任务栏。
 */
export function shelveTask(id, reason = '') {
    return applyTaskCommand({ type: 'shelve', id, payload: { reason } }).ok;
}

/**
 * 判定失败：accepted -> failed（由 timer 在 deadline 到达时调用）。
 * 额外广播 'task:expired'，供视图层弹出"延时 / 搁置"模态框。
 */
export function failTask(id) {
    return applyTaskCommand({ type: 'fail', id, payload: { expired: true } }).ok;
}

/** 重新接取：failed/shelved -> available（清空失败痕迹与 deadline） */
export function reacceptTask(id) {
    return applyTaskCommand({ type: 'reaccept', id }).ok;
}

/* ================= 派活卡导入（阶段6后半 · b） ================= */

/**
 * 按 dispatchKey 稳定键 upsert 一张派活卡：看板 id 固定为 'dp:' + dispatchKey，
 * 跨日 / 跨刷新重复导入始终是同一张卡。
 *  - 已存在：只更新派活内容字段；执行态与时间戳（status / deadline / acceptedAt /
 *    completedAt / failedAt / shelveReason / createdAt）和 id 一概不碰。
 *    内容没变时不落盘不广播，避免每次刷新都触发看板重渲染。
 *  - 新建：执行态用服务端 exec 快照播种。deadline 必须用服务端算好的绝对时间戳，
 *    绝不在本地 now + minutes 重算一遍，否则两套时钟，刷新后倒计时必跳。
 * @param {object} def /api/today 里的 definition
 * @param {object} [exec] 同一任务的服务端执行快照
 * @returns {{ok:boolean, taskId:string|null}}
 */
export function upsertDispatchTask(def, exec = {}) {
    const dispatchKey = def?.dispatchKey;
    if (!dispatchKey) return { ok: false, taskId: null };
    const id = 'dp:' + dispatchKey;
    // 内容映射：定义侧是 title/minutes/why/steps/acceptance/contentRevision。
    // steps 允许数组或字符串两态；render 用 textContent 渲染、\n 不显示，数组以「；」连接成一段。
    // 「知识点」槽位放 acceptance（这张卡怎么算完）——prompt 两千字会撑爆卡片，标签暂不改、名不副实留待以后。
    const content = {
        goal: def.title ?? '',
        suggestion: def.why ?? '',
        measures: Array.isArray(def.steps) ? def.steps.join('；') : (def.steps ?? ''),
        knowledge: def.acceptance ?? '',
        suggestedTime: def.minutes,
        priority: 'medium', // 派活定义没有优先级字段，固定默认值，不猜
        dispatchContentRevision: def.contentRevision ?? null,
        sourceTitle: def.title ?? ''
    };
    const existing = state.tasks.find(t => t.id === id);
    if (existing) {
        const changed = Object.keys(content).some(k => existing[k] !== content[k]);
        if (changed) {
            Object.assign(existing, content);
            persistAndEmit({ type: 'dispatch-upsert', id });
        }
        return { ok: true, taskId: id };
    }
    // 新建：执行态从服务端 exec 播种，两边枚举字面完全一致，不需要映射表
    const task = normalizeTask({
        id,
        dispatchKey,
        blockedBy: [],
        status: exec.execution,
        deadline: exec.deadline,
        acceptedAt: exec.acceptedAt,
        completedAt: exec.completedAt,
        failedAt: exec.failedAt,
        shelveReason: exec.shelveReason ?? '',
        ...content
    });
    state.tasks.push(task);
    persistAndEmit({ type: 'dispatch-upsert', id });
    return { ok: true, taskId: id };
}

/**
 * 每日重置：每天首次调用（或跨天后的下一秒 tick）时执行。
 *  - 更新 lastResetDate；
 *  - 兜底：把跨天时仍挂着但 deadline 已过的任务判为 failed（即"移入失败任务栏"，
 *    视图层会将所有 failed/shelved 任务渲染到失败栏）。
 */
export function dailyResetIfNeeded() {
    const today = todayStr();
    if (state.lastResetDate === today) return;
    state.lastResetDate = today;

    const now = Date.now();
    state.tasks.forEach(t => {
        if (t.status === 'accepted' && t.deadline && t.deadline <= now) {
            t.status = 'failed';
            t.failedAt = now;
            t.deadline = null;
            emit('task:expired', { id: t.id });
        }
    });
    persistAndEmit({ type: 'daily-reset' });
}

/* ================= 数据导出 ================= */

/** 导出全部任务数据（JSON 字符串，供视图层触发下载） */
export function exportData() {
    return JSON.stringify(
        {
            version: SCHEMA_VERSION,
                        exportedAt: (() => {
                const d = new Date();
                const pad = n => String(n).padStart(2, '0');
                return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` +
                       `T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
            })(),
            tasks: state.tasks
        },
        null,
        2
    );
}
